const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef, useCallback } from "react";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Sidebar from "@/components/pilot/Sidebar";
import ChatTopBar from "@/components/pilot/ChatTopBar";
import ChatInput from "@/components/pilot/ChatInput";
import MessageBubble from "@/components/pilot/MessageBubble";
import LoadingDots from "@/components/pilot/LoadingDots";
import EmptyState from "@/components/pilot/EmptyState";
import ScrollToBottom from "@/components/pilot/ScrollToBottom";
import ShareModal from "@/components/pilot/ShareModal";

export default function Chat() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeConvId, setActiveConvId] = useState(null);
  const [localMessages, setLocalMessages] = useState([]);
  const [isResponding, setIsResponding] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [userName, setUserName] = useState("User");

  const messagesEndRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then((u) => {
      if (u?.full_name) setUserName(u.full_name);
    }).catch(() => {});
  }, []);

  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations"],
    queryFn: () => db.entities.Conversation.list("-last_activity"),
  });

  const activeConv = conversations.find((c) => c.id === activeConvId);

  useEffect(() => {
    if (activeConv) {
      setLocalMessages(activeConv.messages || []);
    } else if (!activeConvId) {
      setLocalMessages([]);
    }
  }, [activeConvId, activeConv?.id]);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [localMessages, isResponding, scrollToBottom]);

  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 100;
    setShowScrollBtn(!atBottom);
  };

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.Conversation.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["conversations"] }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.Conversation.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["conversations"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.Conversation.delete(id),
    onSuccess: (_, deletedId) => {
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
      if (activeConvId === deletedId) {
        setActiveConvId(null);
        setLocalMessages([]);
      }
    },
  });

  const handleNewChat = () => {
    setActiveConvId(null);
    setLocalMessages([]);
  };

  const handleRename = async (convId) => {
    const conv = conversations.find((c) => c.id === convId);
    if (!conv) return;
    const newTitle = window.prompt("Rename conversation:", conv.title);
    if (newTitle && newTitle.trim()) {
      await updateMutation.mutateAsync({ id: convId, data: { title: newTitle.trim() } });
    }
  };

  const handleSend = async (text, attachments) => {
    const userMsg = {
      role: "user",
      content: text,
      timestamp: new Date().toISOString(),
      attachments: attachments.length > 0 ? attachments : undefined,
    };

    const newMessages = [...localMessages, userMsg];
    setLocalMessages(newMessages);
    setIsResponding(true);

    let convId = activeConvId;

    if (!convId) {
      const title = text.slice(0, 60) + (text.length > 60 ? "..." : "");
      const created = await createMutation.mutateAsync({
        title,
        messages: newMessages,
        last_activity: new Date().toISOString(),
      });
      convId = created.id;
      setActiveConvId(convId);
    } else {
      await updateMutation.mutateAsync({
        id: convId,
        data: { messages: newMessages, last_activity: new Date().toISOString() },
      });
    }

    // Build prompt
    const fileUrls = attachments.length > 0 ? attachments.map((a) => a.url) : undefined;
    const history = newMessages
      .slice(-10)
      .map((m) => (m.role === "user" ? "User" : "Assistant") + ": " + m.content)
      .join("\n\n");

    const prompt = "You are Pilot, a helpful AI assistant. Respond naturally and helpfully. Use markdown formatting when appropriate (bold, lists, code blocks, etc.). Be concise but thorough.\n\nConversation:\n" + history + "\n\nAssistant:";

    const llmParams = { prompt };
    if (fileUrls) llmParams.file_urls = fileUrls;

    const response = await db.integrations.Core.InvokeLLM(llmParams);

    const aiMsg = {
      role: "assistant",
      content: response,
      timestamp: new Date().toISOString(),
    };

    const finalMessages = [...newMessages, aiMsg];
    setLocalMessages(finalMessages);
    setIsResponding(false);

    await updateMutation.mutateAsync({
      id: convId,
      data: { messages: finalMessages, last_activity: new Date().toISOString() },
    });
  };

  const convTitle = activeConv?.title || (localMessages.length > 0 ? "New conversation" : "");

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
        conversations={conversations}
        activeId={activeConvId}
        onSelectConversation={setActiveConvId}
        onNewChat={handleNewChat}
        onDeleteConversation={(id) => deleteMutation.mutate(id)}
        onRenameConversation={handleRename}
        userName={userName}
      />

      <div className="flex-1 flex flex-col min-w-0 relative">
        <ChatTopBar title={convTitle} onShare={() => setShareOpen(true)} />

        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto"
        >
          {localMessages.length === 0 && !isResponding ? (
            <EmptyState />
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-6">
              {localMessages.map((msg, i) => (
                <MessageBubble key={i} message={msg} />
              ))}
              {isResponding && <LoadingDots />}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <ScrollToBottom visible={showScrollBtn} onClick={scrollToBottom} />

        <ChatInput onSend={handleSend} disabled={isResponding} />
      </div>

      <ShareModal open={shareOpen} onClose={() => setShareOpen(false)} />
    </div>
  );
}